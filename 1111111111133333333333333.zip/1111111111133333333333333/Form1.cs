﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1111111111133333333333333
{
    public partial class Form1 : Form
    {

        private DataGridViewColumn DataGridViewColumn1 = null;
        private DataGridViewColumn DataGridViewColumn2 = null;
        private DataGridViewColumn DataGridViewColumn3 = null;
        private IList<Student> studentList = new List<Student>();
        public Form1()
        {
            InitializeComponent();
            initDataGridView();
        }
        private void initDataGridView() {

            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(getdataGridViewColumn1());
            dataGridView1.Columns.Add(getdataGridViewColumn2());
            dataGridView1.Columns.Add(getdataGridViewColumn3());
            dataGridView1.AutoResizeColumns();
        }

        private DataGridViewColumn getdataGridViewColumn1()
        {
            if (DataGridViewColumn1 == null) {
                DataGridViewColumn1 = new DataGridViewTextBoxColumn();
                DataGridViewColumn1.Name = "";
                DataGridViewColumn1.HeaderText = "Имя";
                DataGridViewColumn1.ValueType = typeof(string);
                DataGridViewColumn1.Width = dataGridView1.Width/3;

            }
            return DataGridViewColumn1;
        }
        private DataGridViewColumn getdataGridViewColumn2()
        {
            if (DataGridViewColumn2 == null)
            {
                DataGridViewColumn2 = new DataGridViewTextBoxColumn();
                DataGridViewColumn2.Name = "";
                DataGridViewColumn2.HeaderText = "Фамилия";
                DataGridViewColumn2.ValueType = typeof(string);
                DataGridViewColumn2.Width = dataGridView1.Width/3;

            }
            return DataGridViewColumn2;
        }

        private DataGridViewColumn getdataGridViewColumn3()
        {
            if (DataGridViewColumn3 == null)
            {
                DataGridViewColumn3 = new DataGridViewTextBoxColumn();
                DataGridViewColumn3.Name = "";
                DataGridViewColumn3.HeaderText = "Номер зачетки";
                DataGridViewColumn3.ValueType = typeof(string);
                DataGridViewColumn3.Width = dataGridView1.Width/3;
            }
            return DataGridViewColumn3;
        }
        private void addStudent(string name, string surname, string recordBookNumber)
        {
            int i = dataGridView1.CurrentRow.Index;
            Student s = new Student(textBox1.Text,textBox2.Text, Convert.ToString(numericUpDown1.Value));
            studentList.Add(s);
            showListInGrid();
        }
        private void deleteStudent(int elementIndex) {
            studentList.RemoveAt(elementIndex);
            showListInGrid();
        }
        private void showListInGrid() {
            dataGridView1.Rows.Clear();
            foreach (Student s in studentList) {
                DataGridViewRow row = new DataGridViewRow();
                DataGridViewTextBoxCell celll = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell2 = new
                DataGridViewTextBoxCell();
                DataGridViewTextBoxCell cell3 = new
                DataGridViewTextBoxCell();
                celll.ValueType = typeof(string);
                celll.Value = s.getName();
                cell2.ValueType =typeof(string);
                cell2.Value = s.getSurname();
                cell3.ValueType = typeof(string);
                cell3.Value = s.getBookname();
                row.Cells.Add(celll);
                row.Cells.Add(cell2);
                row.Cells.Add(cell3);
                dataGridView1.Rows.Add(row);
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addStudent(textBox1.Text,textBox2.Text, Convert.ToString(numericUpDown1.Value));
        }

        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedRow = dataGridView1.SelectedCells[0].RowIndex;
            DialogResult r = MessageBox.Show("Удалить студента?", "", MessageBoxButtons.YesNo);
            if (r == DialogResult.Yes)
            {
                try
                {
                    deleteStudent(selectedRow);
                }
                catch (Exception) { }
            }
        }

        private void сортироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Sort(dataGridView1.Columns[0], ListSortDirection.Ascending);
        }

        private void изменитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            dataGridView1.Rows[i].Cells[0].Value = textBox1.Text;
            dataGridView1.Rows[i].Cells[1].Value = textBox2.Text;
            dataGridView1.Rows[i].Cells[2].Value = textBox3.Text;
        }
    }
}
