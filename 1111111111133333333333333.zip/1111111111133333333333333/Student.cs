﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1111111111133333333333333
{
    class Student
    {
        private string name;
        private string surname;
        private string bookname ;
        public Student(string name, string surname, string recordBookNumber)
        {
            this.name = name;
            this.surname = surname;
            this.bookname = recordBookNumber;
        }

        public string getName()
        {
            return this.name;
        }
        public void setName(string name) {
            this.name = name;
        }
        public string getSurname()
        {
            return this.surname;
        }
        public void setSurname(string surname)
        {
            this.surname = surname;
        }

        public string getBookname()
        {
            return this.bookname;
        }
        public void setBookname(string recordBookNumber)
        {
            this.bookname = recordBookNumber;
        }


    }
}
